(function (NDP, FW) {
    if (!FW) return;

    var thisIsDebug = NDP.isDebug();
    var _console = NDP.console;
    var _currentAdState = null;

    // Events
    var CommandEvent = NDP.events.CommandEvent,
        SystemEvent = NDP.events.SystemEvent,
        AdEvent = NDP.events.AdEvent,
        ErrorEvent = NDP.events.ErrorEvent;
        
    // Details the default FreeWheel configuration settings
    var fwConfig = NDP.configuration.freewheel,
        VIDEO_ASSET_ID = "missing guid", // default error
        VIDEO_DURATION_DEFAULT = 500, // duration default

    // Set FreeWheel AdManager
    AdManager = new FW.AdManager();
    AdManager.setNetwork(fwConfig.network);
    AdManager.setServer(fwConfig.url);
    
    ...
    
    function NativeFreewheelAdapter(parent, domElement) {
        this.parent = parent;
        this.container = domElement;
        this.videoElement = NativeSingleton.getVideoElement();
        this.captions = [];
        this.currentAd = null;
        this.assetURL = null;
        this.slotPositions = null;
        this.isFullScreen = false;
        this.emptiedCount = 0; // used in toggleLock()

        FW.setLogLevel(fwConfig.logLevel || FW.LOG_LEVEL_QUIET);

        this.onVideoError = (function (scope) {
            return function () {
                ...
            };
        }(this));
        
        ...
        
        this.__addHandlers();
        this.initStates(); // todo: move all machine state functionality into Singleton
    }
    
    ...
    
     NativeFreewheelAdapter.prototype.__addHandlers = function () {
        this.parent.addListener(CommandEvent.LOAD, this.__handleLock, this);
        ...
        this.parent.addListener(CommandEvent.FULLSCREEN, this.handleCommand, this);

        NativeSingleton.addListener(SystemEvent.VIDEO_ERROR, this.onVideoError, this);
        NativeSingleton.addListener(SystemEvent.SWITCH_NATIVE_ADAPTERS, this.toggleLock, this);
    };

    NativeFreewheelAdapter.prototype.__removeHandlers = function () {
        this.parent.removeListener(CommandEvent.LOAD, this.__handleLock, this);
        ...
        this.parent.removeListener(CommandEvent.FULLSCREEN, this.handleCommand, this);

        NativeSingleton.removeListener(SystemEvent.VIDEO_ERROR, this.onVideoError, this);
        NativeSingleton.removeListener(SystemEvent.SWITCH_NATIVE_ADAPTERS, this.toggleLock, this);
        
        // FreeWheel iOS Fullscreen bug fix
        this.videoElement.removeEventListener('webkitbeginfullscreen', this.fullscreenHandler); // todo: move to Singleton
        this.videoElement.removeEventListener('webkitendfullscreen', this.fullscreenHandler); // todo: move to Singleton
    };
    
    ...
    
    AdapterFactory.add(NativeFreewheelAdapter);
})(window.$ndp, window.tv && window.tv.freewheel && window.tv.freewheel.SDK);