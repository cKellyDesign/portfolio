(function (ndp){
    var console = ndp.console;

    var AbstractObserver = ndp.AbstractObserver;
    var SystemEvent = ndp.events.SystemEvent;
    var _instance;

    var NATIVE_SUBSCRIPTION_MAP = {
        'emptied' : SystemEvent.SWITCH_NATIVE_ADAPTERS,
        'error' : SystemEvent.VIDEO_ERROR
    };

    function getInstance () {
        if ( !_instance ) _instance = new NativeSingleton();
        return _instance;
    }

    function NativeSingleton() {
        this.containerElement = null;
        this.videoElement = document.createElement("video");
        this.isAdState = false;
        this.src = "";
        this.eventHandler = (function (scope) {
            return function (event) {
                scope.notifyVideoEvent(event);
            };
        })(this);
        this.subscribeNative(true); // Ultimately, this can be the only place that is listening to the video element, all events will then propagate through message bus via this.notify()
    }

    NativeSingleton.prototype = new AbstractObserver();
    NativeSingleton.prototype.constructor = NativeSingleton;
    NativeSingleton.constructor = AbstractObserver.prototype.constructor;

    NativeSingleton.prototype.getVideoElement = function () {
        return this.videoElement;
    };

    /**
     * This function preps and places the video element into the specified
     * container element, after this the video element is ready to have
     * its source set to begin playback.
     * 
     * @param domElement : container element in which to place the video element
     */
    NativeSingleton.prototype.placeVideo = function(domElement) {
        if ( this.containerElement !== null ) return; // this should probably only happen once
        this.containerElement = domElement;
        this.videoElement.controls = !ndp.configuration.useCustomControls;
        this.videoElement.setAttribute("preload", "metadata");
        this.videoElement.setAttribute("x-webkit-airplay", "allow");
        this.containerElement.appendChild(this.videoElement);
        this.videoElement.setAttribute("style", "height: 100%; width: 100%");
    };

    NativeSingleton.prototype.setVideoSrc = function(src) {
        if ( !src ) return;
        this.src = src;
        this.videoElement.src = src;
    };

    /**
     *  Subscribe / Unsubscribe to video element events
     *  @param on : Boolean - Whether to attach or remove listeners
     */
    NativeSingleton.prototype.subscribeNative = function(on) {
        var handler = on ? "addEventListener" : "removeEventListener";
        for (var prop in NATIVE_SUBSCRIPTION_MAP) { // will this iterate over inherited Object properties as well?
            this.videoElement[handler](prop, this.eventHandler);
        }
    };

    /**
     *  This emits an event to which both adapters are subscribed.
     *  This can be generalized to emit SystemEvents for each subscribed video element event.
     */
    NativeSingleton.prototype.notifyVideoEvent =  function(event) {
        var isAdState = (this.src !== this.videoElement.src);
        var newEvent = new SystemEvent(NATIVE_SUBSCRIPTION_MAP[event.type], { isAdState: isAdState, src: this.videoElement.src });
        this.notify(newEvent);
    };

    ndp.NativeSingleton = getInstance;

})(window.$ndp);