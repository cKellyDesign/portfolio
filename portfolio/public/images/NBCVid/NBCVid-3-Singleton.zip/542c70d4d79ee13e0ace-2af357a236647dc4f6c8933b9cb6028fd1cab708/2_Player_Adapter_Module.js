(function (ndp) {
    var console = ndp.console;
    ndp.playbackAdapter = "native";
    var thisIsDebug = ndp.isDebug();

    // Events
    var CommandEvent = ndp.events.CommandEvent;
    var SystemEvent = ndp.events.SystemEvent;
    var PlaybackEvent = ndp.events.PlaybackEvent;
    var ErrorEvent = ndp.events.ErrorEvent;

    // Core system components
    var AdapterFactory = ndp.AdapterFactory;
    var MediaAsset = ndp.MediaAsset;
    var NativeSingleton = ndp.NativeSingleton();
    
    /*
     * Identify commonly used provider EventListeners
     * match Player To Provider Controls and Events
     * @param {type} PlayerIdArr
     * @returns {controller_L1.controller}
     */
    function NativePlayerAdapter(parent, domElement) {
        this.parent = parent;
        this.currentAsset = null;
        this.container = domElement;
        this.videoElement =  NativeSingleton.getVideoElement();
        this.trackElement = null;
        this.ccurl = null;
        this.src = null;

         this.onVideoError = (function (scope) {
            return function () {
                ...
            };
         });
         
        this.__render();
        this.__addHandlers();
    }
    
    ...
    
    NativePlayerAdapter.prototype.__addHandlers = function () {
        this.parent.addListener(CommandEvent.LOAD, this.handleLoad, this);
        ...
        this.parent.addListener(CommandEvent.CAPTION, this.handleCommand, this);

        NativeSingleton.addListener(SystemEvent.VIDEO_ERROR, this.onVideoError, this);
        NativeSingleton.addListener(SystemEvent.SWITCH_NATIVE_ADAPTERS, this.toggleLock, this);
    };

    NativePlayerAdapter.prototype.__removeHandlers = function () {
        this.parent.removeListener(CommandEvent.LOAD, this.handleLoad, this);
        ...
        this.parent.removeListener(CommandEvent.CAPTION, this.handleCommand, this);

        NativeSingleton.removeListener(SystemEvent.VIDEO_ERROR, this.onVideoError, this);
        NativeSingleton.removeListener(SystemEvent.SWITCH_NATIVE_ADAPTERS, this.toggleLock, this);
    };

    // Adapter tells Singleton to handle changing video source attribute
    NativePlayerAdapter.prototype.setVideoSrc = function (src) {
        NativeSingleton.setVideoSrc(src);
    };

    NativePlayerAdapter.prototype.__render = function () {
        NativeSingleton.placeVideo(this.container);
        this.container.setAttribute("style", "height: 100%");

        var systemEvent = new SystemEvent(SystemEvent.PLAYER_LOADED, {});
        systemEvent.autoDispatch = true;
        this.parent.notify(systemEvent);
    };
    
    ...
    
    AdapterFactory.add(NativePlayerAdapter);
})(window.$ndp);