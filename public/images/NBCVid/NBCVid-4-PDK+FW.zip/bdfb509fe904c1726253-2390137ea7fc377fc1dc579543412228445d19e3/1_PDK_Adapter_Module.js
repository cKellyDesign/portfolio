(function (ndp) {
    ndp.playbackAdapter = "pdk";
    // Events
    var CommandEvent = ndp.events.CommandEvent;
    var SystemEvent = ndp.events.SystemEvent;
    var PlaybackEvent = ndp.events.PlaybackEvent;
    var ErrorEvent = ndp.events.ErrorEvent;

    // Core system components
    var AdapterFactory = ndp.AdapterFactory;
    var MediaAsset = ndp.MediaAsset;
    var PDKController = {"unavailable": true};

    // Translates PDK events to NDP events
    var PDK_EVENT_MAP = {
        "OnLoadedRelease": PlaybackEvent.LOADED,
        "OnLoadReleaseUrl": PlaybackEvent.LOADED,
        "OnSetRelease": PlaybackEvent.LOADED,
        "OnSetReleaseUrl": PlaybackEvent.LOADED,
        "OnMediaStart": PlaybackEvent.START,
        "OnMediaPause": PlaybackEvent.PAUSE,
        "OnMediaUnpause": PlaybackEvent.PLAY,
        "OnMediaPlaying": PlaybackEvent.PROGRESS,
        "OnMediaEnd": PlaybackEvent.COMPLETE,
        "OnMediaSeek": PlaybackEvent.SEEK,
        "OnMediaError": ErrorEvent.MEDIA_ERROR,
        "OnReleaseError": ErrorEvent.MEDIA_ERROR
    };

    var metaConfig = {
        "tp:preferredRuntimes": "Universal,HTML5,Flash",
        "tp:PreferredFormats": "FLV,F4M,MPEG4,M3U",
        "tp:initialize": "false"
    };
    
    // List of states the PDK can be in
    var PDK_PLAYER_STATES = {
        "INITIALIZE": 0,
        "READY": 1,
        "LOADING": 2,
        "LOADED": 3
    };

    /**
     * This adapter handles playback of content videos from within a
     * PDK player instance.
     *
     * @param parent : Module - The Module that is the parent of this adapter
     * @param domElement : DOMElement - The DOM element that will contain the rendered video
     * @constructor
     */
    function PDKAdapter(parent, domElement) {

        this.parent = parent;
        this.currentAsset = null;
        this.container = domElement;
        this.id = domElement.id;
        this.player = null;
        this.playerId = this.id + '_player';
        this.queuedEvents = [];
        this.isFirstPlay = true;
        this.state = PDK_PLAYER_STATES.INITIALIZE;

        this.__initialize();
    }
    
    ...
    
     /**
     * Handles the loading of a MediaAsset into the PDK. This method will also determine
     * whether the asset should auto play or not, based on details in the asset as well
     * as whether the device can auto start the video or not.
     * @param event : CommandEvent
     */
    PDKAdapter.prototype.handleLoad = function (event) {
        var _asset = event.getAsset();
        if (!(_asset && _asset.url)) {
            ndp.console.error('MEDIA_ERROR :: Media failed to load correctly:', _asset.url);
            this.parent.notify(new ErrorEvent(ErrorEvent.MEDIA_ERROR, {
                error: 'Media failed to load correctly, MediaAssetID: ' + _asset.id
            }));
        }
        ndp.console.warn('MediaAsset ID :: ' + _asset.getURL() + ' is not currentAsset: ',
            this.currentAsset === null || _asset.id !== this.currentAsset.id, this.currentAsset);

        if (this.currentAsset === null || _asset.getID() !== this.currentAsset.getID()) {
            this.state = PDK_PLAYER_STATES.LOADING;
            this.currentAsset = event.getAsset();
            this.__togglePDKHandlers(true);
            PDKController.clearCurrentRelease();
        }
    };
    
    ...
    
    PDKAdapter.prototype.__triggerQueuedEvents = function () {
        var event = null;

        // So long as the queue has a length greater than 0 we'll
        // loop through and process each queue item.
        while (this.queuedEvents.length) {
            event = this.queuedEvents.shift();

            switch (event.getType()) {
                case CommandEvent.LOAD:
                    this.handleLoad(event);
                    break;
                
                ...    
                
                case CommandEvent.PLAY:
                    this.handlePlay(event);
                    break;
                case CommandEvent.PAUSE:
                    this.handlePause(event);
                    break;
                    
                ...
            }
        }
    };
    
    ...
    
    /**
     * Toggles the PDK event listeners on or off. These are the listeners we attach on
     * the PDK to know what the PDK is doing, then translate them to NDP events and
     * bubble them out of the player to UX.
     * @param on : Boolean - Whether to attach or remove the listeners
     * @private
     */
    PDKAdapter.prototype.__togglePDKHandlers = function (on) {
        var handler = (on === true) ? "addEventListener" : "removeEventListener";

        // Loop through our event map and attach the listeners we are interested in
        for (var key in PDK_EVENT_MAP) {

            // Handler is just a wrapper function for this.__processEvent, which
            // is the actual function called when a PDK event triggers
            PDKController[handler](key, this.handler);
        }
    };
    
    ...
    
    // Assign the adapter to the AdapaterFactory
    AdapterFactory.add(PDKAdapter);
})(window.$ndp);