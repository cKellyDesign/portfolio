(function (ndp) {
    // Events
    var CommandEvent = ndp.events.CommandEvent;
    var SystemEvent = ndp.events.SystemEvent;
    var AdEvent = ndp.events.AdEvent;
    var ErrorEvent = ndp.events.ErrorEvent;

    // Core system components
    var AdapterFactory = ndp.AdapterFactory;
    var PDKController = {};

    // Translates PDK events to ndp events
    var PDK_EVENT_MAP = {
        "OnMediaStart": AdEvent.START,
        "OnMediaUnpause": AdEvent.PLAY,
        "OnMediaPause": AdEvent.PAUSE,
        "OnMediaClick": AdEvent.CLICK,
        "OnMediaPlaying": AdEvent.PROGRESS,
        "OnMediaEnd": AdEvent.COMPLETE,
        "OnMediaError": ErrorEvent.MEDIA_ERROR,
        "OnReleaseError": ErrorEvent.MEDIA_ERROR
    };
    
     /*
    * Identify commonly used provider EventListeners
    * match Player To Provider Controls and Events
    * @param {type} PlayerIdArr
    * @returns {controller_L1.controller}
    */
    function PDKFreewheelAdapter(parent, domElement) {
        this.parent = parent;
        this.container = domElement;

        this.handleStart = (function (scope) {
            return function (event) {
                ...
            };
        } (this));

        this.handleEnd = (function (scope) {
            return function (event) {
                ...
            };
        } (this));

        this.onAdClickHandler = (function (scope) {
            return function () {
                scope.handlePause();
            };
        } (this));

        this.__addFreeWheelConfig();
        this.__checkReady();
    }
    
    ...
    
    PDKFreewheelAdapter.prototype.__togglePDKHandlers = function (on) {
        var handler = on ? "addEventListener" : "removeEventListener";

        for (var key in PDK_EVENT_MAP) {
            if (key !== "OnMediaStart")
                PDKController[handler](key, this.handler);
        }

        if (on) {
            //PDKController.removeEventListener("OnMediaStart", this.handleStart);
            PDKController.addEventListener("OnMediaEnd", this.handleEnd);
            PDKController.addEventListener("OnAdvertisementClick", this.onAdClickHandler);
        } else {
            PDKController.addEventListener("OnMediaStart", this.handleStart);
            PDKController.removeEventListener("OnMediaEnd", this.handleEnd);
            PDKController.removeEventListener("OnAdvertisementClick", this.onAdClickHandler);
        }
    };
    
    ...
    
    AdapterFactory.add(PDKFreewheelAdapter);
})(window.$ndp);