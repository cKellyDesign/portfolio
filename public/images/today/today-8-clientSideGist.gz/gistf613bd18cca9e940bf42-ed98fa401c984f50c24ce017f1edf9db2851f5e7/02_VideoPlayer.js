define([], function() {
  return Backbone.View.extend({

    player: null,
    /* below is for A/B test 3065370591 - remove after test */
    optimizelyEventSent: false,
    optimizelyTestActive: false,
    /* -- end test variables -- */

    initialize: function() {
      this.loadPlayerScript();
      this.initEventSubscription();
    },

    initEventSubscription: function() {
      this.collection.on('reset', this.onPlaylistChange, this);
      Tdy.Events.on('video-player:change-position', this.onPosition, this);
      Tdy.Events.on('video-player:play', this.onPlay, this);
      Tdy.Events.on('video:playlist-panel-tease-click', this.setPreloader, this);
      Tdy.Events.on('video:tease-click', this.setPreloader, this);
      Tdy.Events.on('video:video-controlrack:pause', this.adControlRackPause, this);
      Tdy.Events.on('video:video-controlrack:play', this.adControlRackPlay, this);
    },

    loadPlayerScript: function() {
      var self = this;
      var root = this.getPlayerRoot(window.location.host, '1.0.5');

      var desktop = $('body').hasClass('desktop');

      // for A/B test 3065370591 - uncomment after test
      //root += ( desktop && this.checkForFlash() ) ? '-legacy.js' : '-native.js';

      // for A/B test 3065370591 - remove this 'if' block after test
      // check if: 
      // - it's desktop
      // - the user's browser supports Flash (otherwise force native player)
      // - the first video has autoplay enabled
      if (desktop && this.checkForFlash() && this.isAutoplay()) {
        root += this.getPlayerScriptAndSetupTest();
      } else if (desktop && this.checkForFlash()) {
        root += '-legacy.js';
      } else {
        root += '-native.js';
      }
      /* -- end A/B test logic -- */

      require([root], function() {
        self.initPlayer();
      });
    },

    // for A/B test 3065370591
    isAutoplay: function() {
      if ($('.video-wrapper').length > 0) {
        var firstVideoWrapper = $('.video-wrapper').first();
        var firstVideoContainer = $('.player-l-container', firstVideoWrapper).first();
        var firstVideoData = $(firstVideoContainer).data('video');
        if (firstVideoData.autoPlay) {
          return true;
        }
      }
      
      return false;
    },

    // for A/B test 3065370591
    getPlayerScriptAndSetupTest: function() {
      // testing pool to be 10% of Chrome users
      if (this.isChrome() && Math.random() > 0.9) {
        if (Math.random() > 0.5) {
          // half use normal (PDK) player
          window.optimizely = window.optimizely || [];
          window.optimizely.push(['bucketVisitor', 3065370591, 3045720653]);
          window.optimizely.push(['trackEvent', 'VideoPageLoad']);
          this.optimizelyTestActive = true;
          return '-legacy.js';
        } else {
          // half use native player
          window.optimizely = window.optimizely || [];
          window.optimizely.push(['bucketVisitor', 3065370591, 3058680391]);
          window.optimizely.push(['trackEvent', 'VideoPageLoad']);
          this.optimizelyTestActive = true;
          return '-native.js';
        }
      }

      return '-legacy.js';
    },

    isChrome: function() {
      if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) {
        return true;
      }
      return false;
    },

    checkForFlash: function() {
      return typeof swfobject !== 'undefined' && swfobject.getFlashPlayerVersion().major !== 0;
    },

    getPlayerRoot: function(hostname, version) {
      var root;

      switch(hostname) {
        case 'today-video.herokuapp.com':
          root = 'http://media1.s-nbcnews.com/i/videoassets/staging/ndp/ndpplayer';
          break;
        default:
          root = 'http://media1.s-nbcnews.com/i/videoassets/ndp/' + version + '/ndpplayer';
      }

      return root;
    },

    initPlayer: function() {
      var self = this;
      this.player = new NDPPlayer({
        id: new Date().getTime(),
        location: self.el
      });
      this.bindPlayerEvents();
    },

    onPosition: function(playerWidth, playerHeight, playerTop, playerLeft, guid) {
      this.wrapperGuid = guid;
      $(this.el).css({
        width: playerWidth,
        height: playerHeight,
        display: 'inherit',
        top: playerTop + 'px',
        left: playerLeft + 'px'
      });
    },

    onPlay: function(video, playlistId) {
      if (video.guid) {
        this.currentVideoData = video;
        this.player.mediaAsset(new $ndp.MPXMediaAsset(video));
        this.player.play();
        this.firstVideoIsPlaying = true;
        this.collection.fetch(video.mpxid || video.mpxId, false, playlistId);
      } else {
        this.firstVideoIsPlaying = false;
        this.collection.fetch(video.mpxid || video.mpxId, true, playlistId);
      }
    },

    onPlaylistChange: function() {
      if (this.firstVideoIsPlaying) {
        this.firstVideoIsPlaying = false;
        return;
      }
      this.playNextVideo('playlist');
    },

    playNextVideo: function(playType) {
      $('.j-video-tease.active').removeClass('active');
      var thisNextVideo = this.collection.getNextVideo();
      this.player.mediaAsset(new $ndp.MPXMediaAsset(thisNextVideo));
      this.player.play();
      this.currentVideoData = thisNextVideo;

      if (playType && playType === 'continuous') {
        this.currentVideoData.isContinuousPlay = true;
      }

    },

    bindPlayerEvents: function() {
      var self = this;
      // Video Event Listeners 
      this.player.on($ndp.events.PlaybackEvent.START, _.bind(this.emitPlayerEvent, self));
      this.player.on($ndp.events.PlaybackEvent.PROGRESS, _.bind(this.emitPlayerEvent, self));
      this.player.on($ndp.events.PlaybackEvent.SEEK, _.bind(this.emitPlayerEvent, self));
      this.player.on($ndp.events.PlaybackEvent.COMPLETE, _.bind(this.emitPlayerEvent, self));
      this.player.on($ndp.events.PlaybackEvent.PAUSE, _.bind(this.emitPlayerEvent, self));
      this.player.on($ndp.events.PlaybackEvent.PLAY, _.bind(this.emitPlayerEvent, self));

      //Ad Event Listeners
      this.player.on($ndp.events.AdEvent.START, _.bind(this.emitPlayerEvent, self));
      this.player.on($ndp.events.AdEvent.COMPLETE, _.bind(this.emitPlayerEvent, self));
      this.player.on($ndp.events.AdEvent.PAUSE, _.bind(this.emitPlayerEvent, self));
      this.player.on($ndp.events.AdEvent.PROGRESS, _.bind(this.emitPlayerEvent, self));
      Tdy.Events.trigger('video-player:ready');
    },

    setPreloader: function(val) {
      if (val !== 'none') {
        val = 'table';
      }
      this.$('.loading-container').css('display', val);
    },

    adControlRackPlay: function(e){
      this.player.play();
    },

    adControlRackPause: function(e){
      this.player.pause();
    },

    emitPlayerEvent: function(e) {
      // console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~    Event Type: ", e.type[0]);
      switch (e.type[0]) {
        case 'NDP_PlaybackEvent_START':
          this.setPreloader('none');
          Tdy.Events.trigger('video:playback-event-start', this.currentVideoData, this.wrapperGuid, e);

          // for A/B test 3065370591
          if (!this.optimizelyEventSent && this.optimizelyTestActive) {
            try {
              window.optimizely.push(['trackEvent', 'VideoStart']);
              this.optimizelyEventSent = true;
            } catch(error) {}
          }
          break;
        case 'NDP_PlaybackEvent_PROGRESS':
          Tdy.Events.trigger('video:playback-event-progress', this.currentVideoData, this.wrapperGuid, e);
          break;
        case 'NDP_PlaybackEvent_SEEK':
          Tdy.Events.trigger('video:playback-event-seek', this.currentVideoData, this.wrapperGuid, e);
          break;
        case 'NDP_PlaybackEvent_COMPLETE':
          Tdy.Events.trigger('video:playback-event-complete', this.currentVideoData, this.wrapperGuid, e);
          this.playNextVideo('continuous');
          break;
        case 'NDP_PlaybackEvent_PAUSE':
          Tdy.Events.trigger('video:playback-event-pause', this.currentVideoData, this.wrapperGuid, e);
          break;
        case 'NDP_PlaybackEvent_PLAY':
          Tdy.Events.trigger('video:playback-event-play', this.currentVideoData, this.wrapperGuid, e);
          break;
        case 'NDP_AdEvent_START':
          this.setPreloader('none');
          Tdy.Events.trigger('video:ad-event-start', this.currentVideoData, this.wrapperGuid, e);
          
          // for A/B test 3065370591
          if (!this.optimizelyEventSent && this.optimizelyTestActive) {
            try {
              window.optimizely.push(['trackEvent', 'VideoStart']);
              this.optimizelyEventSent = true;
            } catch(error) {}
          }
          break;
        case 'NDP_AdEvent_COMPLETE':
          Tdy.Events.trigger('video:ad-event-complete', this.currentVideoData, this.wrapperGuid, e);
          break;
        case 'NDP_AdEvent_PAUSE':
          Tdy.Events.trigger('video:ad-event-pause', this.currentVideoData, this.wrapperGuid, e);
          break;
        case 'NDP_AdEvent_PROGRESS':
          Tdy.Events.trigger('video:ad-event-progress', this.currentVideoData, this.wrapperGuid, e);
          break;
        default:
          break;
      }
    }

  });
});