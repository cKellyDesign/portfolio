require([
  'common/mixins/Initialization',
  'common/mixins/VideoInit',
  'common/ads/cover-front-placements',
  'views/quickshare'
  ], function (InitializationMixin, VideoInit, AdPlacements, Quickshare) {

  var Front = Backbone.View.extend({

    el: 'body',
    content: '.content',
    adController: null,
    stream: null,
    videoRail: null,
    isFoodFront: $('.content').hasClass('visual-layout'),

    events: {
      'click .j-video-tease': 'onVideoRailTeaseClick'
    },  

    initialize: function() {
      this.initHeader();
      this.initNav();
      this.initStream();
      this.initVideoIfEligible(true);
      this.initResponsiveImages();
      if ( typeof mps !== 'undefined' ) {
        this.initAdPlacements();
        this.initAds();
      }
      this.initTracking();
      
      if (this.isFoodFront) {
        this.initTopModule();
        this.initCarousel();
        this.initFrontBlocksFilter();
        this.initShareBars();
      }

    },

    initAdPlacements: function() {
      var adPlacements = new AdPlacements({el: $('.stream')});
    },

    containsVideoPlayer: function(){
      var bodyContext = $('body').data('context');
      return bodyContext === 'j-concertSeries' || bodyContext === 'j-videoHub' || bodyContext === 'j-topModule';
    },

    onVideoRailTeaseClick: function(e) {
      if (this.containsVideoPlayer()) { // This will only be still be false if the front is eligible for the video player, intent is that clicking teases on such a front won't open a new window
        return;
      }
      e.preventDefault();
      e.stopPropagation();
      var url = $(e.target).hasClass('j-rail-item') ? $(e.target).attr('href') : $(e.target).parents('.j-rail-item').attr('href');
      window.open( url, 'TodayVideoPlayer', 'width=996,height=740,status=1,scrollbars=yes,resizable=yes,toolbar=0,menubar=0,titlebar=0,directories=0');
    }

  });

  _.extend(Front.prototype, InitializationMixin);
  _.extend(Front.prototype, VideoInit);

  Tdy = window.Tdy || {};
  Tdy.Events = {};
  _.extend(Tdy.Events, Backbone.Events);
  Tdy.Front = new Front();
});