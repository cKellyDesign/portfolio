define([
    'jquery-mobile',
    'velocity',
    'velocity-ui'
    ], function(){
    var Carousel = Backbone.View.extend({

        interval: 5000,
        intervalHandler: null,
        currentIndex: 0,
        slides: this.$('.j-slide-item'),
        dots: this.$('.j-carousel-dot'),
        slidesLength: null,
        isPlaying: false,

        events: {
            'click .j-carousel-dot': 'onDotClick',
            'click .j-slide-item' : 'onTeaseClick',
            'swiperight': 'onSwipeRight',
            'swipeleft': 'onSwipeLeft'
        },

        initialize: function() {
            this.slidesLength =  this.slides.length;
            if (!$('body').hasClass('no-js')){
                $(this.slides[0]).show();
            }
            this.registerEffects();
            this.subscribeToEvents();
            this.startCarousel();
        },

        subscribeToEvents: function() {
            Tdy.Events.on('video:playback-event-start video:ad-event-start video:playback-event-play', this.stopCarousel, this);
            Tdy.Events.on('video:playback-event-pause video:playback-event-complete', this.startCarousel, this);
            window.addEventListener('focus', this.startCarousel.bind(this));
            window.addEventListener('blur', this.stopCarousel.bind(this));
        },

        onDotClick: function(e) {
            e.stopPropagation();
            e.preventDefault();

            var $target = $(e.target).hasClass('j-carousel-dot') ? $(e.target) : $(e.target).parents('.j-carousel-dot');
            var clickedIndex = $target.index();

            if (clickedIndex === this.currentIndex) { // if clicked dot is active
                if (this.isPlaying) {
                    this.stopCarousel(); // stopping on the first active dot click
                } else {
                    this.startCarousel(); // starting on second active dot click
                }
                return; // Don't get next slide
            } else {
                if (this.isPlaying) {
                    this.stopCarousel(); // stop the carousel on non-active dot clicks
                }
                this.trackCarouselDotClick(clickedIndex);
            }

            this.goToSlide(clickedIndex);
        },

        onTeaseClick: function(e){
            var index = this.currentIndex || 0;
            analyticsDataLayer.linkSection = (index + 1).toString();
            _satellite.track('carouselTease');
        },

        trackCarouselDotClick: function(clickedIndex){
            var index = clickedIndex || 0;
            analyticsDataLayer.linkSection = (index + 1).toString();
            analyticsDataLayer.linkLocation = 'Carousel';
            _satellite.track('frontCarousel');
        },

        startCarousel: function() {
            if (this.isPlaying) {
                return;
            }
            var self = this;
            this.isPlaying = true;
            this.intervalHandler = setInterval(function(){
                self.nextSlide();
            }, self.interval);
        },

        stopCarousel: function() {
            if (!this.isPlaying) {
                return;
            }
            this.isPlaying = false;
            clearInterval(this.intervalHandler);
        },

        nextSlide: function(swipe){
            swipe = swipe ? "swipeRight" : false;
            if (this.currentIndex === this.slidesLength - 1) {
                this.goToSlide(0, swipe); // go to first slide
            }  else {
                this.goToSlide(this.currentIndex + 1, swipe);
            }
        },

        prevSlide: function(swipe){
            swipe = swipe ? "swipeLeft" : false;
            if (this.currentIndex === 0) {
                this.goToSlide(this.slidesLength - 1, swipe); // go to last slide
            } else {
                this.goToSlide(this.currentIndex - 1, swipe);
            }
        },

        goToSlide: function(index, swipe) {
            var transitionIn;
            var transitionOut;
            if (swipe === "swipeLeft") {
                transitionIn = 'simpleTrans.slideFromRightIn';
                transitionOut = 'simpleTrans.slideFromRightOut';
            } else if (swipe === "swipeRight") {
                transitionIn = 'simpleTrans.slideFromLeftIn';
                transitionOut = 'simpleTrans.slideFromLeftOut';
            } else {
                transitionIn = 'transition.fadeIn';
                transitionOut = 'transition.fadeOut';
            }
            $(this.slides[index]).velocity(transitionIn);
            $(this.dots[this.currentIndex]).removeClass('active');
            $(this.dots[index]).addClass('active');
            $(this.slides[this.currentIndex]).velocity(transitionOut);
            this.currentIndex = index;
        },

        onSwipeRight: function(e) {
            e.preventDefault();
            e.stopPropagation();
            this.prevSlide(true);
            this.stopCarousel();
        },

        onSwipeLeft: function(e) {
            e.preventDefault();
            e.stopPropagation();
            this.nextSlide(true);
            this.stopCarousel();
        },

        registerEffects: function() {
            $.Velocity.RegisterEffect("simpleTrans.slideFromLeftIn", {
                defaultDuration: 400,
                calls: [
                    [ { translateX: "100%", opacity: 0 }, 0.00001 ],
                    [ { opacity: 1}, 0.00001 ],
                    [ { translateX: "0%" }, 0.99998 ]
                ]
            });
            $.Velocity.RegisterEffect("simpleTrans.slideFromLeftOut", {
                defaultDuration: 400,
                calls: [
                    [ { translateX: "-100%" }, 1, { delay: 75 } ]
                ],
                reset: { translateX: "0%" }
            });
            $.Velocity.RegisterEffect("simpleTrans.slideFromRightIn", {
                defaultDuration: 400,
                calls: [
                    [ { translateX: "-100%", opacity: 0 }, 0.00001 ],
                    [ { opacity: 1}, 0.00001 ],
                    [ { translateX: "0%" }, 0.99998 ]
                ]
            });
            $.Velocity.RegisterEffect("simpleTrans.slideFromRightOut", {
                defaultDuration: 400,
                calls: [
                    [ { translateX: "100%" }, 1, { delay: 75 } ]
                ],
                reset: { translateX: "0%" }
            });
        }
    });
    return Carousel;
});