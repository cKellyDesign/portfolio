define([], function() {
  return Backbone.View.extend({

    initialize: function(options) {
      this.guid = options.guid;
      this.$el.attr('data-wrapper-guid', this.guid);
      this.resizeHandler = _.bind(this.triggerChangePosition, this);
      this.relativeTopElement = options.relativeTopElement;
      this.playerContainer = this.$('.player-l-container');
      this.defaultVideoData = $(this.playerContainer).data('video'); // Not in model because we want these values stored for resetting to loaded values.
      this.initEventSubscription();
      if ($('body').hasClass('canonicvideo')) {
        this.initWindowResizeBinding();
      }
    },

    initEventSubscription: function() {
      Tdy.Events.on('video-player:ready', this.onPlayerReady, this);
      Tdy.Events.on('video:tease-click', this.onTeaseClick, this);
      Tdy.Events.on('video:play-playlist', this.onPlaylistPlay, this);
      Tdy.Events.on('video:playback-event-start video:ad-event-start', this.onPlayerStart, this);
      //Tdy.Events.on('video:ad-event-start', this.toggleAd, this);
      //Tdy.Events.on('video:playback-event-complete', this.removeAd, this);
    },

    onPlayerReady: function() {
      this.checkForAutoplayEligibleVideo();
    },

    initWindowResizeBinding: function() {
      $(window).on('resize', this.resizeHandler);
    },

    endWindowResizeBinding: function() {
      $(window).off('resize', this.resizeHandler);
    },

    onTeaseClick: function(teaseModel, guid, playlistId) {
      if (guid !== 'all' && guid !== this.guid) {
        $(this.playerContainer).removeAttr('style');
        this.resetElementsToDefaultValues();
        this.endWindowResizeBinding();
        Tdy.Events.off('ads:refreshed-pageflow', this.resizeHandler);
        return;
      }

      this.triggerChangePosition();
      this.setContainerZindex();
      Tdy.Events.on('ads:refreshed-pageflow', this.resizeHandler);
      Tdy.Events.trigger('video-player:play', teaseModel, playlistId);
    },

    onPlaylistPlay: function(playlist, mpxid) {
      this.triggerChangePosition();
      this.setContainerZindex();

      Tdy.Events.trigger('video-player:play-playlist', playlist, mpxid);
    },

    onPlayerStart: function(videoData, guid) {
      if (guid !== 'all' && guid !== this.guid) {
        return;
      }
      if (!$('body').hasClass('canonicvideo')) {
        this.initWindowResizeBinding();
      } else {
        this.checkSponsoredVideo(videoData);
      }
      this.triggerChangePosition();
      this.updateElementValues(videoData);
    },

    checkSponsoredVideo: function(videoData) {
      var isSponsoredVideo = this.$el.hasClass('sponsored-video');
      // todo: lets get api to return an 'isSponsored' property on the video so we don't have to maintain such silly conditionals. - Conor
      if (isSponsoredVideo && !videoData.isSponsored) {
        this.$el.removeClass('sponsored-video');
      } else if (!isSponsoredVideo && videoData.isSponsored) {
        this.$el.addClass('sponsored-video');
      }
    },

    updateElementValues: function(videoData) {
      //console.log(this);
      this.$('.player-headline-mobile').html(videoData.title);
      this.$('.player-headline-info').html(videoData.title);
      this.$('.player-headline').html(videoData.title);
      this.$('.video-pubdate').html(videoData.pub_date_user_facing);
      this.$('.video-description').html(videoData.description);
      this.$('.player-tease-img').attr('src', videoData.thumbnail);
    },

    resetElementsToDefaultValues: function() {
      this.$('.player-headline-mobile').html(this.defaultVideoData.title);
      this.$('.player-headline-info').html(this.defaultVideoData.title);
      this.$('.player-headline').html(this.defaultVideoData.title);
      this.$('.video-pubdate').html(this.defaultVideoData.pub_date_user_facing);
      this.$('.video-description').html(this.defaultVideoData.description);
      this.$('.player-tease-img').attr('src', this.defaultVideoData.thumbnail);
    },

    checkForAutoplayEligibleVideo: function() {
      var desktop = $('body').hasClass('desktop');
      if (desktop && this.defaultVideoData.autoPlay) {
        Tdy.Events.trigger('video:tease-click', this.defaultVideoData, this.guid);
      }
    },

    triggerChangePosition: function() {
      var self = this;
      setTimeout(function(){
        var playerWidth = self.playerContainer.outerWidth();
        var playerHeight = playerWidth * 0.5625; // This forces a 9:16 ratio every time and does not require the image to be fully loaded to take this measurment
        var playerTop = self.playerContainer.offset().top - $(self.relativeTopElement).offset().top;
        var playerLeft = (self.playerContainer.offset().left) - (self.relativeTopElement.offset().left);
        Tdy.Events.trigger('video-player:change-position', playerWidth, playerHeight, playerTop, playerLeft, self.guid);
      }, 250); // This is necessary because when the page is resized, this entire func runs before the page flow has finished updating (paragraphs become narrower and taller)
    },

    setContainerZindex: function() {
      $(this.playerContainer).css('z-index', '-1');
    }

  });
});