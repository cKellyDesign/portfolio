define([], function() {
  return Backbone.View.extend({

    events: {
      'click': 'onTeaseClick'
    },

    inPlaylistPanel: false,
    context: null,
    currentTease: null,

    initialize: function(options) {
      this.inPlaylistPanel = options.inPlaylistPanel;
      this.wrapperGuid = options.wrapperGuid;
      this.context = $('body').data('context') || null;
      this.playlistId = this.$el.data('playlistid') || null;
      this.initEventSubscription();
    },

    initEventSubscription: function() {
      var self = this;

      Tdy.Events.on('video:tease-click', _.bind(this.determineActiveState, this));
      Tdy.Events.on('video:playlist-panel-tease-click', _.bind(this.determineActiveState, this));
      Tdy.Events.on('video:playback-event-start', function(videoData, guid) {
        self.determineActiveState(videoData.mpxId, guid);
      });
      Tdy.Events.on('video:ad-event-start', function(videoData, guid) {
        self.determineActiveState(videoData.mpxId, guid);
      });
    },

    onTeaseClick: function(e) {
      e.preventDefault();
      this.backToTop();


      if (this.inPlaylistPanel) {
        Tdy.Events.trigger('video:playlist-panel-tease-click', this.model.get('mpxid') || this.model.get('mpxId'), this.wrapperGuid);
      } else {
        Tdy.Events.trigger('video:tease-click', this.model.toJSON(), this.wrapperGuid, this.playlistId);
      }
    },

    determineActiveState: function(mpxid, guid) {
      if (guid !== 'all' && guid !== this.wrapperGuid) {
        return;
      }
      var self = this;
      var theMpxid = mpxid.mpxid || mpxid; // What is emitted through events
      var thisMpxid = this.model.get('mpxid') || this.model.get('mpxId'); // Specific to individual tease

      if (theMpxid === thisMpxid) {
        self.$el.addClass('active');
        self.currentTease = theMpxid;
      } else {
        this.currentTease = null;
      }
    },

    backToTop: function() {
      if ( $('body').data('context') === 'j-videoHub' || $('body').data('context') === 'j-concertSeries' || $('body').data('context') === 'j-canonical' ) {
        $("html,body").animate({
          scrollTop: 0
        }, 500);
      }
    }

  });

});