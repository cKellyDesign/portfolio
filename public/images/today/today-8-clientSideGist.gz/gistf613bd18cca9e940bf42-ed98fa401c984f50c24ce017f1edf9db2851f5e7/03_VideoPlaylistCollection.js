define([
  'common/views/videoPlayer/VideoModel'
], function(VideoModel) {
  return Backbone.Collection.extend({

    AJAX_CALL_BASE: '/getAssociatedPlaylistFor/',
    currentVideoId: 0,

    initialize: function() {
      Tdy.Events.on('video-player:play-playlist', this.onPlayPlaylist, this);
    },

    onPlayPlaylist: function(playlist, mpxid) {
      var videoModel = _.findWhere(playlist, { mpxId: mpxid.toString() });
      this.currentVideoId = playlist.indexOf(videoModel);

      this.reset(_.map(playlist, function(playlistVideo) {
        return new VideoModel(playlistVideo);
      }));
    },

    fetch: function(mpxid, playFirst, playlistId) {
      var appendFirstVideo = playFirst ? 'true' : 'false';
      var thisPlaylistId = playlistId && playlistId !== 'false' ? playlistId : 'false';
      $.get(this.AJAX_CALL_BASE + mpxid + '/withPlaylist/' + thisPlaylistId + '/' + appendFirstVideo, _.bind(this.resetModels, this));
    },

    loadPlaylist: function(playlist) {
      if (typeof playlist === 'string'){
        playlist = JSON.parse(playlist);
      }
      if (!playlist || playlist.length === 0) {
        return;
      }
      this.resetModels({
        playlist: playlist
      });
    },

    resetModels: function(videoData) {
      this.currentVideoId = 0;
      if (typeof videoData === 'string'){
        videoData = JSON.parse(videoData);
      }
      if (!videoData || videoData.length === 0) {
        return;
      }
      this.reset(_.map(videoData.playlist, function(playlistVideo) {
        return new VideoModel(playlistVideo);
      }));
    },

    getNextVideo: function() {
      var nextVideo = this.at(this.currentVideoId).toJSON();
      this.currentVideoId++;

      if (this.currentVideoId >= this.length) {
        this.currentVideoId = 0;
      }
      
      return nextVideo;
    }
  });

});