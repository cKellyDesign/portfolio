var path = require('path');
var moment = require('moment');
var packageJson = require('./package.json');
var viewportSizes = require('./acceptance-test/config/viewport-sizes.js');

module.exports = function (grunt) {
  // Load grunt tasks automatically
  require('load-grunt-tasks')(grunt);
  // Time how long tasks take (to optimize build times)
  require('time-grunt')(grunt);

  grunt.initConfig({
    express: {
      main: {
        options: {
          port: 9001,
          script: './web.js',
          spawn: false,
          opts: []
        }
      }
    },

    watch: {
      express: {
        files: ['./web.js', './router.js', 'server/**/**/*.js', 'routes/*.js'],
        tasks: ['express'],
        options: {
          livereload: true
        }
      },
      scss: {
        files: 'app/styles/**/*.scss',
        tasks: ['sass:dev'],
        options: {
          livereload: true
        }
      },
      js: {
        files: 'app/scripts/**/**/**/**/*.js',
        tasks: [
          'requirejs:dev'
        ],
        options: {
          livereload: true
        }
      },
      staticpages: {
        files: 'app/styles/staticpages/**/*.scss',
        tasks: ['sass:staticpages'],
        options: {
          livereload: true
        }
      },
      reload: {
        files: [
          'build/scripts/**/*.js',
          'build/scripts/desktop-entrypage.js',
          'build/scripts/tablet-entrypage.js',
          'build/scripts/mobile-entrypage.js',
          'build/styles/main.css',
          'build/styles/main-tablet.css',
          'views/**/**/*.hbs',
          'server/**/**/*.js',
          'routes/*.js',
          './router.js'
        ],
        options: {
          livereload: true
        }
      }
    },

    sass: {
      dev: {
        files: [{
          expand: true,
          cwd: 'app/styles',
          src: ['**/*.scss', '!staticpages/**/*.scss'],
          dest: 'build/styles',
          ext: '.css'
        }],
        options: {
          style: 'expanded'
        }
      },
      staticpages: {
        files: [{
          expand: true,
          cwd: 'app/styles',
          src: ['**/*.scss'],
          dest: 'build/styles',
          ext: '.css'
        }],
        options: {
          style: 'expanded'
        }
      },
      prod: {
        files: [{
          expand: true,
          cwd: 'app/styles',
          src: ['**/*.scss'],
          dest: '.tmp/styles',
          ext: '.css'
        }],
        options: {
          style: 'compressed'
        }
      }
    },

    // Adds vendor prefixes automatically
    autoprefixer: {
      options: {
        browsers: ['last 5 version']
      },
      all: {
        files: [
          {
            expand: true,
            cwd: '.tmp/styles/',
            src: '**/{,*/}*.css',
            dest: 'build/styles/'
          }
        ]
      }
    },

    jshint: {
      all: ['app/scripts/**/**/**/**/**/*.js',
            'server/**/*.js',
            'routes/*.js',
            'test/**/**/**/*.js',
            '!test/data/*.js',
            '!test/TestFeedData.js',
            '!routes/TestFeedData.js',
            '!app/scripts/staticpages/app/**/*.js',
            '!app/scripts/staticpages/connect/bootstrap.min.js'
            ],
      options: {
        curly: true,
        eqeqeq: true,
        immed: true,
        latedef: 'nofunc',
        undef: false,
        unused: false,
        laxbreak: true,
        globals: {
          jQuery: true,
          require: true
        },
        devel: {
          console: true
        }
      }
    },

    mocha_casperjs: {
      options: {
       timeout: 120000, // test case timeout
       casperTimeout: 30000 // step and waitFor* timeout
      },
      mobile: {
        src: ['acceptance-test/*.js'],
        options: viewportSizes.getDimensions('mobile'),
        includes: [
          "acceptance-test/viewport-sizes.js"
        ]
      },
      tablet: {
        src: ['acceptance-test/*.js'],
        options: viewportSizes.getDimensions('tablet'),
        includes: [
          "acceptance-test/viewport-sizes.js"
        ]
      },
      desktopXS: {
        src: ['acceptance-test/*.js'],
        options: viewportSizes.getDimensions('desktopXS'),
        includes: [
          "acceptance-test/viewport-sizes.js"
        ]
      },
      desktopS: {
        src: ['acceptance-test/*.js'],
        options: viewportSizes.getDimensions('desktopS'),
        includes: [
          "acceptance-test/viewport-sizes.js"
        ]
      },
      desktopM: {
        src: ['acceptance-test/*.js'],
        options: viewportSizes.getDimensions('desktopM'),
        includes: [
          "acceptance-test/viewport-sizes.js"
        ]
      },
      desktopL: {
        src: ['acceptance-test/*.js'],
        options: viewportSizes.getDimensions('desktopL'),
        includes: [
          "acceptance-test/viewport-sizes.js"
        ]
      },
      desktopXL: {
        src: ['acceptance-test/*.js'],
        options: viewportSizes.getDimensions('desktopXL'),
        includes: [
          "acceptance-test/viewport-sizes.js"
        ]
      }
    },

    // Optimizes images
    imagemin: {
      all: {
        files: [
          {
            expand: true,
            cwd: 'app/img',
            src: ['**/*.{png,jpg,jpeg,gif}'],
            dest: 'app/img'
          }
        ]
      }
    },

    copy: {
      dev: {
        "files": [
          { "cwd": "app/fonts/", "src": ["**"], "dest": "build/fonts", "expand": true },
          { "cwd": "app/img/", "src": ["**"], "dest": "build/img", "expand": true },
          { "cwd": "components/requirejs/", "src": ["require.js"], "dest": "build/scripts", "expand": true },
          { "cwd": "components/respond/dest", "src": ["respond.min.js"], "dest": "build/scripts", "expand": true },
          { "cwd": "components/html5shiv/dist/", "src": ["html5shiv.min.js"], "dest": "build/scripts", "expand": true},
          { "cwd": "app/scripts/config/", "src": ["config.js"], "dest": "build/scripts/config", "expand": true },
          { "cwd": "app/scripts/staticpages/", "src": ["**"], "dest": "build/scripts/staticpages", "expand": true }

        ]
      },
      prod: {
        "files": [
          { "cwd": "app/fonts/", "src": ["**"], "dest": "build/fonts", "expand": true },
          { "cwd": "app/img/", "src": ["**"], "dest": "build/img", "expand": true },
          { "cwd": "components/requirejs/", "src": ["require.js"], "dest": "build/scripts", "expand": true },
          { "cwd": "components/respond/dest", "src": ["respond.min.js"], "dest": "build/scripts", "expand": true },
          { "cwd": "components/html5shiv/dist/", "src": ["html5shiv.min.js"], "dest": "build/scripts", "expand": true},
          { "cwd": "app/scripts/staticpages/", "src": ["**"], "dest": "build/scripts/staticpages", "expand": true }
        ]
      }
    },

    mochaTest: {
      test: {
        options: {
          reporter: 'spec'
        },
        src: ['test/**/**/*Tests.js']
      }
    },

/* ...... */

    parallel: {
      dev: {
        tasks: [
          {
            grunt: true,
            args: ['requirejs:dev']
          },
          {
            grunt: true,
            args: ['sass:dev']
          }
        ]
      },
      prod: {
        tasks: [
          {
            grunt: true,
            args: ['requirejs:prod']
          },
          {
            grunt: true,
            args: ['sass:prod']
          }
        ]
      }
    },

/* ...... */


  var formFactors = ['desktop', 'tablet', 'mobile'];
  var appTypes = ['cover', 'entrypage', 'front', 'search', 'canonicvideo', 'externalvideo'];
  var envs = ['dev', 'prod'];
  var modules = [];

  modules.push({
    name: 'config/vendor',
    //List common dependencies here. Only need to list
    //top level dependencies, "include" will find
    //nested dependencies.
    include: ['jquery',
    'backbone',
    'underscore',
    'hand',
    'requireLib'
    ]
  });

  for (var i = 0; i < formFactors.length; i++) {
    for (var j = 0; j < appTypes.length; j++) {
      modules.push({
        name: formFactors[i] + '/' + appTypes[j],
        override: {
          paths: {
            'views': './' + formFactors[i] + '/views',
            'ads': './' + formFactors[i] + '/ads',
            'tracking': './' + formFactors[i] + '/tracking'
          }
        },
        exclude: ['config/vendor']
      });
    }
  }

  for (var i = 0; i < envs.length; i++) {
    var env = envs[i];

    grunt.config(['requirejs', env], {
      options: {
        appDir: 'app/scripts',
        dir: 'build/scripts/',
        mainConfigFile: 'app/scripts/config/vendor.js',
        modules: modules,
        paths: {
	        requireLib: '../../components/requirejs/require'
        },
        optimize: env === 'dev' ? 'none': 'uglify2'
      }
    });
  }

  grunt.config(['compress', 'main'], {
    options: {
      archive: packageJson.version + '.zip',
      mode: 'zip'
    },
    files: getBuildPackageFiles('/')
  });

  grunt.config(['rpm', 'main'], {

    options: {
      destination: 'rpm',
      name: 'today.com',
      version: packageJson.version.replace('-', '_'),
      release: true,
      homepage: 'http://www.today.com',
      summary: 'Today.com Nodejs application',
      group: 'Web'
    },
    files: getBuildPackageFiles('/opt/today.com/')
  });

  grunt.registerTask('default', [
    'env:dev',
    'serve'
  ]);

  grunt.registerTask('noprod', [
    'env:noprod',
    'serve'
  ]);

  grunt.registerTask('prod', [
    'env:prod',
    'serve'
  ]);

  grunt.registerTask('staging', [
    'env:staging',
    'serve'
  ]);

  grunt.registerTask('serve', [
    'jshint',
    'parallel:dev',
    'copy:dev',
    'express',
    'watch'
  ]);

  grunt.registerTask('build', [
    'jshint',
    'clean',
    'parallel:prod',
    'autoprefixer:all',
    'copy:prod'
    ]);

  grunt.registerTask('heroku', [
    'clean',
    'parallel:prod',
    'autoprefixer:all',
    'copy:prod'
    ]);

  grunt.registerTask('test', ['env:test', 'mochaTest']);
  grunt.registerTask('acceptance-test', ['env:noprod', 'express', 'mocha_casperjs:mobile','mocha_casperjs:tablet', 'mocha_casperjs:desktopXS', 'mocha_casperjs:desktopS', 'mocha_casperjs:desktopM', 'mocha_casperjs:desktopL', 'mocha_casperjs:desktopXL']);
  grunt.registerTask('release', ['gitcheckout:staging', 'gitcheckout:release', 'bumpup', 'gitcommit:release', 'gitcheckout:master', 'gitmerge:release', 'gittag:release', 'gitpush:master', 'gitcheckout:staging', 'gitmerge:master', 'gitpush:staging']);
  grunt.registerTask('deploy-s3-prod', ['gitcheckout:master', 'heroku', 'compress', 's3']);
  grunt.registerTask('deploy-s3-alpha', ['gitcheckout:staging', 'compress', 's3']);
  grunt.registerTask('rpmbuild', ['heroku', 'rpm']);
};

/* ...... */