var extend = require('util')._extend;
var newsApiService = require('./server/newsApiService');
var params = require('express-params');

var coverRoutes = require('./routes/cover')(newsApiService);
var staticRoutes = require('./routes/static');
var noprodRoutes = require('./routes/noprod');

var steppedRouteHandler = require('./steppedRouteHandler');

exports.setRoutes = function(app, handlers) {

  params.extend(app);

  app.get('/', steppedRouteHandler('cover', handlers.cover));
  app.get('/sitemap', steppedRouteHandler('sitemap', handlers.sitemapPage));
  app.get('/info/header', steppedRouteHandler('externalHeader', handlers.externalHeader));
  app.get('/info/footer', function (req, res) {
    res.status(200);
    res.set('Content-type', 'text/html');
    res.render('externalFooter', {'layout':false});
  });

  app.get('/robots.txt', function (req, res) {
    if (process.env.HOST_NAME === 'www.today.com') {
      res.sendFile(__dirname + '/robots_prod.txt');
    } else {
      res.sendFile(__dirname + '/robots_staging.txt');
    }
  });

  app.get(/^(\/status)(\/)*$/, coverRoutes.status);

  // START static routes
  app.get('/info/terms-and-conditions', routeHandler('terms', handlers.termsAndConditions, false));
  app.get('/info/contact-us', routeHandler('contact', handlers.contact, false));
  app.get('/info/closed-captioning', routeHandler('closed-captioning', handlers.closedCaptioning, false));
  app.get('/info/emmy', staticRoutes.emmy);
  app.get('/info/connect', staticRoutes.connect);
  app.get('/info/app', staticRoutes.apps);
  app.get('/info/apps', function(req, res) {
    res.redirect(301, '/info/app');
  });
  
  /* ...... */

  app.get('/food/recipes/weeknight-wonders-5-healthy-speedy-meals/solutions', calendarRouteHandler);
  app.get('/food/summer-produce-your-guide-to-whats-in-season-and-how-to-eat-it/solutions', calendarRouteHandler);
  app.get('/food/7-days-of-one-pot-dinners/solutions', calendarRouteHandler);
  app.get('/home/best-summer-ever-21-days-of-summer-home-diys/solutions', calendarRouteHandler);
  app.get('/style/30-days-of-cool-summer-style/solutions', calendarRouteHandler);
	app.get('/money/priceless-tips-easy-ways-to-save-time-and-money/solutions', calendarRouteHandler);
  
  app.get('/captions/*', function (req, res) {
    var filePath = req.url.replace('/captions/', '');
    var truePath = 'http://videocaptions.nbcnews.com/' + filePath;
    res.redirect(302, truePath);
  });

  // 404 Route catchall for static routes
  notFoundHandler('/info/*');

  // redirect for orlando parks promotion (temp until we get our redirect service operational)
  app.get('/enter', function(req, res) {
    res.redirect(302, 'http://events.today.com/');
  });

  // END static routes
  app.get('/search', routeHandler('search', handlers.search));

  // 404 Route catchall for search routes
  notFoundHandler('/search/*');

  if (app.get('env') !== 'production') {
    app.get('/rendering/todaycoverfeed', noprodRoutes.coverfeed);
    app.get('/rendering/todaycover/as/json/for/VideoFavorites', noprodRoutes.videoTimeline);
    app.get('/rendering/video/:workbenchId/mobile_web/for/cpp', noprodRoutes.videoJson);
    app.get('/rendering/video/asseturls', noprodRoutes.videoUnicornUrls);

    app.get('/500', function (req, res) {
      req.log.info('Testing 500 error page');
      res.status(500);
      res.set('Content-type', 'text/html');
      res.sendFile(__dirname + '/views/500.html');
    });
  }

  // Video
  app.param('mpxId', /\d+$/);
  app.get('/video/:videoTitle-:mpxId', steppedRouteHandler('video-canonical', handlers.canonicVideoStepped));
  app.get('/video/today/:wbId', steppedRouteHandler('video-canonical', handlers.workbenchVideo));

  app.get('/video', steppedRouteHandler('video-hub', handlers.videoHubStepped));
  app.get('/offsite/:title-:mpxId', steppedRouteHandler('video-offsite', handlers.offsiteVideoMpx));
  app.get('/offsite/today/:wbId', steppedRouteHandler('video-offsite', handlers.offsiteVideoWb));
  
  // Video Json
  app.param('appendFirst', /^(true|false)$/i);
  app.get('/getAssociatedPlaylistFor/:videoId/withPlaylist/:playlistId/:appendFirst', steppedRouteHandler('json', handlers.videoAjaxRequestStepped, 'application/json'));
  app.get('/getPlaylist/:playlistId', steppedRouteHandler('json', handlers.videoPlaylistAjaxStepped, 'application/json'));
  app.get('/oembed', function(req, res, next) {
    var format = req.query.format || 'json';
    req.mediaType = format === 'json' ? 'application/json+oembed' : 'text/xml+oembed';
    return next();
  }, steppedRouteHandler('json', handlers.oembedVideo));

  // Sitemaps
  app.get('/sitemap/googlenews', xmlHandler(handlers.googleNews));
  app.get('/sitemap/:section/xml', xmlHandler(handlers.sitemap));
  app.get('/sitemap/:section/xml/page/:page', xmlHandler(handlers.sitemap));

  // Articles
  app.param('flowArticle', /^([a-zA-Z0-9-]+-\d{1}[a-fA-F]{1}[\d]+|[a-zA-Z0-9-]+-\d{3,7})$/); // matches FLOW article format "unauthorized-saved-bell-story-1D80040483"
  app.param('iVillageArticle', /^[a-zA-Z0-9-]+-[iI][\d]+$/);

  app.param('article', /^[a-zA-Z0-9-]+-t[\d]+$/); // matches Drupal article format "unauthorized-saved-bell-story-t1000"
  app.param('section', /^[a-zA-Z0-9-]+$/);
  app.param('topic', /^[a-zA-Z0-9-]+$/);
  app.param('subtopic', /^[a-zA-Z0-9-]+$/);
  app.param('speciallabel', /^(trending|royals|holidays|books|back-to-school)$/i);
  app.param('specialshow', /^(orangeroom|klgandhoda|todays-take)$/i);

  app.get('/:speciallabel', function(req, res, next) {
    req.params.label = req.params.speciallabel[0];
    return next();
  }, steppedRouteHandler('partials/front/front', handlers.frontStepped));

  app.get('/:specialshow', function(req, res, next) {
    req.params.show = req.params.specialshow[0];
    return next();
  }, steppedRouteHandler('partials/front/front', handlers.frontStepped));

  app.get('/appview/series/:series/:article', steppedRouteHandler('partials/article/article-appview', handlers.appViewArticleStepped));
  app.get('/appview/:section/:article', steppedRouteHandler('partials/article/article-appview', handlers.appViewArticleStepped));
  app.get('/appview/:section/:iVillageArticle', steppedRouteHandler('partials/article/article-appview', handlers.appViewArticleStepped));
  app.get('/appview/:section/:flowArticle', steppedRouteHandler('partials/article/article-appview', handlers.appViewArticleStepped));
  app.get('/series/:series/:article', steppedRouteHandler('article', handlers.articleStepped));
  app.get('/:section/:article', steppedRouteHandler('article', handlers.articleStepped));
  app.get('/:section/:flowArticle', steppedRouteHandler('article', handlers.flowArticleStepped));
  app.get('/:section/:iVillageArticle', steppedRouteHandler('article', handlers.articleStepped));

  // Ajax articles
  app.get('/getnextarticle/series/:series/:endtime', steppedRouteHandler('partials/article/article', handlers.articlePartial));
  app.get('/getnextarticle/section/:section/:endtime', steppedRouteHandler('partials/article/article', handlers.articlePartial));
  app.get('/getnextarticle/topic/:topic/:endtime', steppedRouteHandler('partials/article/article', handlers.articlePartial));
  app.get('/getnextarticle/subtopic/:subtopic/:endtime', steppedRouteHandler('partials/article/article', handlers.articlePartial));
  app.get('/getnextarticle/label/:label/:endtime', steppedRouteHandler('partials/article/article', handlers.articlePartial));
  app.get('/getnextarticle/show/:show/:endtime', steppedRouteHandler('partials/article/article', handlers.articlePartial));
    
  // Fronts
  app.get('/label/:label', steppedRouteHandler('partials/front/front', handlers.frontStepped));
  app.get('/series/:series', steppedRouteHandler('partials/front/front', handlers.frontStepped));
  app.get('/:specialshow/label/:label', function(req, res, next) {
    req.params.show = req.params.specialshow[0];
    return next();
  }, steppedRouteHandler('partials/front/front', handlers.frontStepped));
  app.get('/:section', steppedRouteHandler('partials/front/front', handlers.frontStepped));
  app.get('/:section/topic/:topic', steppedRouteHandler('', handlers.topicRedirectsStepped));
  app.get('/:section/tag/:tag', steppedRouteHandler('', handlers.tagRedirectsStepped));
  app.get('/:section/label/:label', steppedRouteHandler('partials/front/front', handlers.frontStepped));
  app.get('/:section/:topic', steppedRouteHandler('partials/front/front', handlers.frontStepped));
  app.get('/:section/:topic/:subtopic', steppedRouteHandler('partials/front/front', handlers.frontStepped));

  // Fronts Ajax Calls
  app.get('/getStreamBlocksAjax/:primaryTaxon/:taxonType/:taxon', steppedRouteHandler('partials/stream/stream-ajax', handlers.streamBlocksAjaxStep));
  app.get('/getVideoBlocksAjax/:primaryTaxon/:taxonType/:taxon', steppedRouteHandler('partials/stream/stream-ajax', handlers.videoBlocksAjaxStep))

  // 404 Route catchall (Must always be at the bottom)
  notFoundHandler('*');

  function notFoundHandler(route) {
    app.get(route, function (req, res) {
      req.log.info('Page not found: ' + req.originalUrl);
      res.status(404);
      res.set('Content-type', 'text/html');
      res.render('404', {'layout':false});
    });
  }

  function calendarRouteHandler(req, res, next) {
    var handler = steppedRouteHandler('calendar', handlers.calendarStepped);
    if (res.locals.formfactor.tablet) {
      res.locals.formfactor.tablet = false;
      res.locals.formfactor.desktop = true;
      res.locals.formFactor = 'desktop';
    }
    handler(req, res, next);
  }
};

function makeOptions(req, res) {
  var params = paramsToLowercaseString(req.params);
  var options = extend(params, paramsToLowercaseString(req.query));
  options.formfactor = res.locals.formfactor;
  options.log = req.log;
  return options;
}

function routeHandler(view, builder) {
  return function (req, res, next) {
    req.params.referrer = req.get('referrer') || '';

    var options = makeOptions(req, res);

    builder(options, function (err, viewModel) {
      if (err) {
        next(err);
        return;
      }

      if (!viewModel) {
        req.log.info('Page not found: ' + req.originalUrl);
        res.status(404);
        res.set('Content-type', 'text/html');
        res.render('404', {'layout':false});
        return;
      }

      res.render(view, viewModel, function(err, html) {
        if (err) {
          next(err);
        } else {
          req.log.info(view + ' view render complete.');
          res.set('Content-type', 'text/html');
          res.send(html);
        }
      });
    });
  };
}

/* ..... */