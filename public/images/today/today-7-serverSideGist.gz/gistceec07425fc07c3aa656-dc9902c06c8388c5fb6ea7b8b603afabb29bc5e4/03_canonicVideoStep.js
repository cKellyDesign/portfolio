var Promise = require('bluebird');
var util = require('util');
var moment = require('moment');
var _ = require('underscore');
var playlistById = require('./playlistById');
var videoByMpxId = require('./videoByMpxId');
var videoModel = require('./videoModel');
var getTaxonomies = require('./articleModel').getTaxonomies;
var getAnalyticsData = require('./../helpers/analyticsHelper');

var RedirectError = require('./../errors').RedirectError;
var defaultMetadata = require('./../helpers/metadataHelper');
var getAimsUrl = require('./../helpers/aimsHelper');
var mpxApiEndpoint = process.env.WEBAPP_API_BASE_PATH + 'getbympxid?output=today&type=video&mpxid=%s';
var wbApiEndpoint = process.env.WEBAPP_API_BASE_PATH + 'getbyid?output=today&id=workbench/video/%s';
var oembedEndpoint = '/oembed?format=%s&url=%s';


module.exports = function init(api) {
  function wb(options) {
    var videoEndpoint = util.format(wbApiEndpoint, options.wbId);
    // remove embedded hashtags from the url ... this breaks any query param which may came after (GitHub 3627)
    var sanitizedVideoEndpoint = videoEndpoint.replace(/#\d+/gi, "");
    var query = api(sanitizedVideoEndpoint, options.log);
    return build(query, options);
  }

  function mpx(options) {
    var videoEndpoint = util.format(mpxApiEndpoint, options.mpxId);
    var query = api(videoEndpoint, options.log);
    return build(query, options);
  }
  
  function build(query, options) {
    return query.then(function(videoData){
      if (!videoData) {
        var port = process.env.PORT === '9001' ? ':9001' : '';
        throw new RedirectError('http://' + process.env.HOST_NAME + port + '/video');
      }
      var thisResult = videoData.results[0];
      var thisVideo = thisResult.video;
      thisVideo.autoPlay = true;
      var thisModel = {
        context: 'canonical',
        appView: 'canonicvideo',
        appType: 'canonicvideo',
        embedCode: videoModel.returnVideoEmbedCode(thisVideo),
        mpxId: thisVideo.mpxId,
        canonicalUrl: thisResult.canonical_url,
        canonicRelativeUri: videoData.results[0].canonical_url.replace('http://www.today.com/',''),
        oembedJsonUrl: util.format(oembedEndpoint, 'json', thisResult.canonical_url),
        oembedXmlUrl: util.format(oembedEndpoint, 'xml', thisResult.canonical_url),
        video: videoModel.buildVideoModel(thisVideo, 'canonical', function(url) {
          return getAimsUrl.canonicalVideoFeatured(url, options.formfactor);
        }),
        ads: getAdTaxonomies(options),
        analytics: getAnalyticsData.canonical(options),
        metadata: {
          title: thisResult.page_title + ' - TODAY.com',
          socialHeadline: thisResult.seo_Headline || thisResult.cover_Headline,
          canonical_url: thisResult.canonical_url,
          type: 'video',
          og_image: thisResult.main_art && thisResult.main_art.url || defaultMetadata.avatarUrl,
          image: thisResult.main_art && thisResult.main_art.url || defaultMetadata.avatarUrl,
          pub_date: moment(new Date(thisResult.first_published_utc)).format('YYYY-MM-DDTHH:mm:ss[Z]'),
          pub_date_user_facing: moment(new Date(thisResult.first_published_utc)).format('MMMM Do, YYYY'),
          facebook: defaultMetadata.facebook,
          twitter: defaultMetadata.twitter,
          tumblr: defaultMetadata.tumblr,
          instagram: defaultMetadata.instagram,
          newsletter: defaultMetadata.newsletter,
          rss: defaultMetadata.rss,
          google_news_keywords: populateGoogleNewsKeywords(getTaxonomies(thisResult)),
          description: thisResult.summary
        }
      };
      thisModel.playlistsToQuery = videoModel.getMultiplePlaylistModel(thisVideo.video_playlists, thisModel.video.isSponsored);
      return thisModel;
    })
    .then(function(viewModel){
      options.videoContext = 'canonical';

      if (!viewModel.playlistsToQuery) {
        return viewModel;
      }

      return playlistById.plural(api, viewModel.playlistsToQuery, options, true)
	  .then(function(playlistsData){
	    if (!playlistsData){
              throw new ResourceNotFoundError();
	    }
	    return videoModel.dataToPlaylist(playlistsData, viewModel.playlistsToQuery);
	  })
	  .then(function(playlists){
	    viewModel.topVideosPlaylist = playlists[0] ? videoModel.buildPlaylistModel(playlists[0], 7, aimsSizer(options)) : null;
	    viewModel.associatedPlaylist = playlists[1] ? videoModel.buildPlaylistModel(playlists[1], 4, aimsSizer(options)) : null;
	    viewModel.secondaryPlaylist = playlists[2] ? videoModel.buildPlaylistModel(playlists[2], 4, aimsSizer(options)) : null;
	    viewModel.tertiaryPlaylist = playlists[3] ? videoModel.buildPlaylistModel(playlists[3], 4, aimsSizer(options)) : null;
	    
	    return viewModel;
	  });
      });
  }

  return {
    mpx: mpx,
    wb: wb
  };
};

function aimsSizer(options) {
  return function(url) {
    return getAimsUrl.videoSmallTease(url, options.formfactor);
  };
}

function populateGoogleNewsKeywords(taxonomies) {
  var keywords = taxonomies.map(function (taxon) {
    return taxon.title;
  });

  return _.uniq(_.compact(keywords)).join();
}

function getAdTaxonomies(options) {
  // todo: this needs to not be hardcoded as this is, it will need to be refactored to fit in with Andreas's work
  return {
    'cag[platform]': 'web',
    'type': 'canonical-video',
    'cat': "canonical_video",
    'site': 'todayshow',
    'path': options.path
  };
}