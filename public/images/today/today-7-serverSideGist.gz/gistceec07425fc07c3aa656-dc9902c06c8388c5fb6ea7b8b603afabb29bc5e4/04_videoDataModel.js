var _ = require('underscore');
var moment = require('moment');
var relatedLabel = "Related Videos";
var getAimsUrl = require('./../helpers/aimsHelper');

// Standard Data Returned for Video Teases
function mapVideo(thisVideo, aimsSizer, firstPubUTC) {
  if (!thisVideo) {
    return;
  }
  return {
    legacy_url: thisVideo.canonicalUrl,
    canonical_url: thisVideo.canonicalUrl,
    mpxId: thisVideo.mpxId,
    thumbnail: aimsSizer ? aimsSizer(thisVideo.thumbnail) : thisVideo.thumbnail,
    canonicalUrl: thisVideo.canonicalUrl,
    description: thisVideo.description,
    title: thisVideo.title,
    socialTitle: thisVideo.title,
    guid: thisVideo.guid,
    newsNetwork: thisVideo.source, // This is our hook for Sponsored Videos : if === 'Sponsored'
    isSponsored: (thisVideo.source && thisVideo.source.indexOf('Sponsored') !== -1) || (thisVideo.source && thisVideo.source.indexOf('Native') !== -1),
    videoType: thisVideo.videoType,
    mezzVersion: thisVideo.mezzVersion,
    embedCode: returnVideoEmbedCode(thisVideo),
    videoAssets: thisVideo.videoAssets,
    duration: thisVideo.duration,
    pub_date: firstPubUTC ? moment(new Date(firstPubUTC)).format('YYYY-MM-DDTHH:mm:ss[Z]') : null,
    pub_date_user_facing: firstPubUTC ? moment(new Date(firstPubUTC)).format('MMMM Do, YYYY') : null
  };
}

// Standard Data Returned For Playlist
function buildPlaylistModel(playlist, numToReturn, aimsSizer){
  if (!playlist) {
    return null;
  }
  return {
    playlist_id: playlist.playlist_id,
    playlist_label: playlist.label,
    playlist_context: playlist.playlist_context,
    playlist_title: playlist.label.replace(/_/g, ' '),
    playlist_results: playlist.playlist_results.map(function(result) {
      return mapVideo(result.video, aimsSizer || getAimsUrl.coverVideoSmall, result.first_published_utc);
    }).slice(0, numToReturn)
  };
}

// Creates an Ingestible Array of Playlists for module playlistById.plural
function getMultiplePlaylistModel(rawPlaylists, isSponsoredVideoPlaylist) {
  if (!rawPlaylists || rawPlaylists.length < 1) {
    return null;
  }
  rawPlaylists[0].label = relatedLabel;
  convertPlaylistID(rawPlaylists);

  var topVideosPlaylist = [{playlist_id: 'nnd_26411480', label: 'TODAY Top Videos'}];
  if (isSponsoredVideoPlaylist) { // If this is a playlist for sponsored video, do not append playlist fallbacks
    topVideosPlaylist.push(rawPlaylists[0]);
    return topVideosPlaylist;
  }

  var fallbackPlaylists = [ // List of Fallback Playlists
    {playlist_id: 'nnd_49287195', label: 'TRENDING'},
    {playlist_id: 'nnd_45558311', label: 'LIFESTYLE'},
    {playlist_id: 'nnd_55181665', label: 'News Nuggets'}
  ];

  var allPlaylists = topVideosPlaylist.concat(rawPlaylists, fallbackPlaylists);
  var uniquePlaylists = _.uniq(allPlaylists, false, function(playlist){ return playlist.playlist_id; });

  return uniquePlaylists.slice(0,4);
}

// Standard Data Returned for Video Object
function buildVideoModel(thisVideo, context, aimsSizer){
  if (!thisVideo){
    return;
  }
  var thisSource = thisVideo.source || thisVideo.newsNetwork;
  return {
    context: context,
    mpxId: thisVideo.mpxId,
    thumbnail: aimsSizer ? aimsSizer(thisVideo.thumbnail) : thisVideo.thumbnail,
    canonicalUrl: thisVideo.canonicalUrl,
    description: thisVideo.description,
    title: thisVideo.title,
    socialTitle: thisVideo.title,
    videoType: thisVideo.videoType,
    mezzVersion: thisVideo.mezzVersion,
    guid: thisVideo.guid,
    newsNetwork: thisSource,
    isSponsored: (thisSource && thisSource.indexOf('Sponsored') !== -1) || (thisSource && thisSource.indexOf('Native') !== -1),
    autoPlay: thisVideo.autoPlay || false,
    embedCode: returnVideoEmbedCode(thisVideo),
    videoAssets: thisVideo.videoAssets,
    duration: thisVideo.duration,
    pubDate: moment(new Date(thisVideo.pubDate)).format('YYYY-MM-DDTHH:mm:ss[Z]'),
    pub_date_user_facing: moment(new Date(thisVideo.pubDate)).format('MMMM Do, YYYY')
  };
}

// This manipulates the raw data returned from playlistById.plural
function dataToPlaylist(playlistByIdPluralResponse, arrayOfPlaylists){
  _.compact(playlistByIdPluralResponse);
  var playlistContexts = {0: 'top', 1: 'associated', 2: 'secondary', 3: 'tertiary'};
  var theseVideoTeaseIds = [];

  var filterForUniqueResults = function(playlistResults) {
    var uniqueResults = [];
    _.each(playlistResults, function(result){
      if (!result.video) {
        return;
      }
      if(!_.contains(theseVideoTeaseIds, result.video.mpxId)){
        uniqueResults.push(result);
        theseVideoTeaseIds.push(result.video.mpxId);
      }
    });
    return uniqueResults;
  };

  return playlistByIdPluralResponse.map(function(playlistResponseData, playlistIndex){
    var toFilter = (arrayOfPlaylists[playlistIndex].playlist_id === 'nnd_26411480') ? false : true; // Does this playlist ID match "Most Watched"?
    return {
      label: arrayOfPlaylists[playlistIndex].label || relatedLabel,
      playlist_id: arrayOfPlaylists[playlistIndex].playlist_id,
      playlist_context: playlistContexts[playlistIndex] || playlistResponseData.label,
      playlist_results: toFilter ? filterForUniqueResults(playlistResponseData.results) : playlistResponseData.results
    };
  }).filter(function(uniquePlaylist) {
    return uniquePlaylist.playlist_results.length > 0;
  });
}

function convertPlaylistID (playlistArray){
  var thisArray = _.compact(playlistArray);
  return thisArray.map(function(playlistItem){
    if (!playlistItem){
      return;
    }
    playlistItem.playlist_id = playlistItem.playlist_id.replace('dev', 'nnd');
  });
}

function returnVideoEmbedCode (video) {
  if (!(video && video.canonicalUrl)) {
    return null;
  }
  var embedCode = '<div style="position:relative; padding-bottom:63%; padding-bottom:-webkit-calc(56.25% + 50px); padding-bottom:calc(56.25% + 50px); height: 0;">' +
        '<iframe style="position:absolute; width: 100%; height: 100%;" ' + 
        'src="' + video.canonicalUrl.replace('/video/', '/offsite/') + '" scrolling="no" frameborder="0"></iframe>' +
        '</div>';
  return encodeURI(embedCode);
}

module.exports = {
  mapVideo: mapVideo,
  buildPlaylistModel: buildPlaylistModel,
  buildVideoModel: buildVideoModel,
  dataToPlaylist: dataToPlaylist,
  convertPlaylistID: convertPlaylistID,
  getMultiplePlaylistModel: getMultiplePlaylistModel,
  returnVideoEmbedCode: returnVideoEmbedCode
};