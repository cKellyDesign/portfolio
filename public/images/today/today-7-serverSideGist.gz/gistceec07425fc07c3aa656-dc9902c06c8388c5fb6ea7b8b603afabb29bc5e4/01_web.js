var Promise = require('bluebird');
var initApp = require('./initapp');

var handlers = bootstrap();

var app = initApp(handlers);

app.listen(app.get('port'), function() {
  console.log('Server running on port ' + app.get('port'));
});

function bootstrap() {

  var api = require('./server/newsApiService');

  var googlenewsSitemapBuilder = require('./server/builders/googlenewsSitemapViewModelBuilder')(api);
  var sitemapBuilder = require('./server/builders/sitemapViewModelBuilder')(api);
  var menuAndMarqueeWrapper = require('./server/wrappers/menuAndMarqueeWrapper');

  //search front
  var searchBuilder = menuAndMarqueeWrapper(require('./server/builders/searchViewModelBuilder')(api), api);
  //static
  var termsBuilder = menuAndMarqueeWrapper(require('./server/builders/static/termsViewModelBuilder')(), api);
  var sitemapPageBuilder = menuAndMarqueeWrapper(require('./server/builders/static/sitemapPageViewModelBuilder')(api), api);
  var contactBuilder = menuAndMarqueeWrapper(require('./server/builders/static/contactViewModelBuilder')(), api);
  var closedCaptioningBuilder = menuAndMarqueeWrapper(require('./server/builders/static/closedCaptioningViewModelBuilder')(), api);

  var calendar = require('./server/steps/calendar')(api);
  var mainNavMenu = require('./server/steps/menuById')(api, 1);
  var showMeMenu = require('./server/steps/showMeMenu')(api);
  var marquee = require('./server/steps/marquee')(api);
  var cover = require('./server/steps/cover')(api);
  var front = require('./server/steps/front')(api);
  var streamBlocksAjax = require('./server/steps/frontAjax')(api);
  var videoBlocksAjax = require('./server/steps/videoBlocks')(api);
  var article = require('./server/steps/article')(api);
  var articlePartial = require('./server/steps/articlePartial')(api);
  var canonicVideo = require('./server/steps/canonicVideo')(api);
  var sitemapPage = require('./server/steps/sitemapPage');

  var playlistByTax = require('./server/steps/playlistByTax')(api);
  var coverVideoRail = require('./server/steps/playlistById').step(api, 'nnd_45557102', true);

  var concertSeriesVideos = require('./server/steps/concertSeriesVideos')(api);
  var videoHub = require('./server/steps/videoHub')(api);
  var externalVideo = require('./server/steps/externalVideo')(api);
  var oembedVideo = require('./server/steps/oembedVideo')(api);
  var legacyRedirects = require('./server/steps/legacyRedirects');
  var videoAjax = require('./server/steps/videoAjaxRequest')(api);
  var videoPlaylistAjax = require('./server/steps/videoPlaylistAjaxRequest')(api);
  var setLayoutFalse = require('./server/steps/setLayout')(false);
  var setLayoutAppview = require('./server/steps/setLayout')('appview');

  var articleStepped = [
  article, mainNavMenu, showMeMenu, marquee];

  var flowArticleStepped = [
  legacyRedirects.flowArticle, article, mainNavMenu, marquee];

  var articlePartialStepped = [
  setLayoutFalse, articlePartial];

  var calendarStepped = [
  calendar, mainNavMenu, showMeMenu];

  var frontStepped = [ legacyRedirects.section, front, mainNavMenu, showMeMenu, marquee, playlistByTax ];

  var concertSeriesStepped = [ concertSeriesVideos, front, mainNavMenu, marquee ];

 /* ..... */

  var videoHubStepped = [videoHub, mainNavMenu, marquee];

  var tagRedirectStep = [legacyRedirects.tag];

  var topicRedirectStep = [legacyRedirects.topic];

  var videoAjaxRequest = [setLayoutFalse, videoAjax];

  var videoPlaylistAjaxRequest = [setLayoutFalse, videoPlaylistAjax];

  var appViewArticleStepped = [article, setLayoutAppview];

  var streamBlocksAjaxStep = [streamBlocksAjax, setLayoutFalse];

  var videoBlocksAjaxStep = [videoBlocksAjax, setLayoutFalse];

  var oembedVideoStep = [setLayoutFalse, oembedVideo];


  return {
    articlePartial: articlePartialStepped,
    cover: newCoverStepped,
    googleNews: googlenewsSitemapBuilder,
    search: searchBuilder,
    sitemap: sitemapBuilder,
    calendarStepped: calendarStepped,
    articleStepped: articleStepped,
    flowArticleStepped: flowArticleStepped,
    appViewArticleStepped: appViewArticleStepped,
    frontStepped: frontStepped,
    concertSeries: concertSeriesStepped,
    canonicVideoStepped: mpxVideoStepped,
    workbenchVideo: workbenchVideo,
    offsiteVideoMpx: externalVideoMpx,
    offsiteVideoWb: externalVideoWb,
    oembedVideo: oembedVideoStep,
    tagRedirectsStepped: tagRedirectStep,
    topicRedirectsStepped: topicRedirectStep,
    videoAjaxRequestStepped: videoAjaxRequest,
    videoPlaylistAjaxStepped: videoPlaylistAjaxRequest,
    termsAndConditions: termsBuilder,
    sitemapPage: sitemapPageStepped,
    contact: contactBuilder,
    closedCaptioning: closedCaptioningBuilder,
    videoHubStepped: videoHubStepped,
    externalHeader: externalHeaderStep,
    streamBlocksAjaxStep: streamBlocksAjaxStep,
    videoBlocksAjaxStep: videoBlocksAjaxStep
  };
}